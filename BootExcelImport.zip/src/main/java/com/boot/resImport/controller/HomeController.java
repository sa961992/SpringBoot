package com.boot.resImport.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.resImport.model.StudentModel;
import com.boot.resImport.service.ExcelImporterService;

@RestController
@RequestMapping("/web")
public class HomeController {
	
	@Autowired
	ExcelImporterService excelImporter;
	
	private final static String IMPORT_PATH = "/import/excel";

	@RequestMapping(IMPORT_PATH)
	public List<StudentModel> importFromExcel() {		
		return excelImporter.excelImport();
	}
	
}
