package com.boot.resImport.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IndexErrorController implements ErrorController{

    private static final String PATH = "/error";

    @RequestMapping(value = PATH)
    public String error(HttpServletRequest req) {
    	Integer statusCode = (Integer)req.getAttribute("javax.servlet.error.status_code");
    	Exception exception = (Exception) req.getAttribute("javax.servlet.error.exception");
        return statusCode + " : " + exception.getMessage();
    }

    @Override
    public String getErrorPath() {
        return PATH;
    }
}