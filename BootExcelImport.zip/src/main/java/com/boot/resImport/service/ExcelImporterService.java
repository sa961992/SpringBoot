package com.boot.resImport.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.resImport.model.CustomConfigModel;
import com.boot.resImport.model.StudentModel;


@Service
public class ExcelImporterService {
	
	@Autowired
	CustomConfigModel config;
	
	
	public List<StudentModel> excelImport(){
		List<StudentModel> listStudent=new ArrayList<>();
		int sid=0;
		String sname="";
		String saddress="";
		String scity="";
		try {
			Workbook workbook=new XSSFWorkbook(config.getInputStream());
			Sheet firstSheet=workbook.getSheetAt(0);
			Iterator<Row> rowIterator=firstSheet.iterator();
			rowIterator.next();
			while(rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				Iterator<Cell> cellIterator=nextRow.cellIterator();
				while(cellIterator.hasNext()) {
					Cell nextCell=cellIterator.next();
					int columnIndex=nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						sid=(int)nextCell.getNumericCellValue();
						break;
					case 1:
						sname=nextCell.getStringCellValue();
						break;
					case 2:
						saddress=nextCell.getStringCellValue();
						break;
					case 3:
						scity=nextCell.getStringCellValue();
						break;
					
					}
				}
				listStudent.add(new StudentModel(sid, sname, saddress, scity));
			}
			
			workbook.close();
		} catch (Exception e) {
			throw new RuntimeException("Error in excelImport", e);
		}
		
		return listStudent;
	}

}
