package com.boot.resImport.model;

public class StudentModel {
	
	private int sid;
	private String sname;
	private String saddress;
	private String scity;
	
	
	public StudentModel(int sid, String sname, String saddress, String scity) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.saddress = saddress;
		this.scity = scity;
	}
	public StudentModel() {
		super();
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	
}
