package com.boot.resImport.model;

import java.io.FileInputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties
public class CustomConfigModel {
	
	@Autowired
	private ResourceLoader resourceLoader;

	@Value("${resource.excelImport}")
	private String excelImport;
	
	@Value("${resource.rawPrefixPath}")
	private String rawPrefixPath;

	public String getExcelImport() {
		return excelImport;
	}

	public void setExcelImport(String excelImport) {
		this.excelImport = excelImport;
	}
	
	public FileInputStream getInputStream() {
		FileInputStream stream=null;
		try { 
			stream = new FileInputStream(resourceLoader.getResource(rawPrefixPath+"/"+excelImport).getFile());
		} catch (IOException e) {
			throw new RuntimeException("Error while retrieving excelDB",e);
		}
		return stream;
		
	}
	
}
